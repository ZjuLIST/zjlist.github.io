cordova.define("cordova-plugin-utilities.MyData", function(require, exports, module) {
var MyData = function() {
    
};

module.exports = MyData;

});
