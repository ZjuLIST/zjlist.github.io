//
//  xtract.h
//  testCallCpp
//
//  Created by list on 2017/1/8.
//  Copyright © 2017年 list. All rights reserved.
//

#ifndef xtract_h
#define xtract_h


__BEGIN_DECLS
void output(int size, float *X, float *Y, float *Z, float *wX, float *wY,
            float *wZ, float *gX, float *gY, float *gZ, float res[]);


__END_DECLS
#endif /* xtract_h */
